<?php
/* 
	To run sample application you need to have:
	- PHP
	- MySQL
	
	To install application, just make sure that your MySQL running and load index.php 
	after entering suitable (for you) information below
*/
    $mysql_host = "db2.dhtmlx.com";
    $mysql_user = "dhtmuzer_ro";
    $mysql_pasw = "gp45_gm";
    $mysql_db   = "dhtmlxsamples";
?>