//v.2.6 build 100722

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/

 
 dataProcessor.prototype.setOnAfterUpdate = function(ev){this.attachEvent("onAfterUpdate",ev);};dataProcessor.prototype.enableDebug = function(mode){};dataProcessor.prototype.setOnBeforeUpdateHandler=function(func){this.attachEvent("onBeforeDataSending",func);};
//v.2.6 build 100722

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/