dhtmlxChart v.2.6.5  Standard edition build 101011

This component is allowed to use under GPL or you need to obtain Commercial or Enterise License
to use it in not GPL project. PLease contact sales@dhtmlx.com for details


(c) DHTMLX Ltd. 