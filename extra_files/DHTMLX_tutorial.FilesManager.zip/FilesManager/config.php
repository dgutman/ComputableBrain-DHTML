<?php
	$gl_starting_directory = "c:/Program Files";
	$gl_file_types = array("txt"=>"Text File","gif"=>"GIF Image","doc"=>"Word Document","html"=>"HTML Document");
?>