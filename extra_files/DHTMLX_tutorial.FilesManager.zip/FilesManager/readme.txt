dhtmlxLayout. From layout to Interface (File Manager Application)

This package contains files which are mentioned in the tutorial here: http://docs.dhtmlx.com/doku.php?id=tutorials:dhtmlx_layoutguide:tut_dhtmlxlayout
codebase folder contains Standard Editon of DHTMLX Library

(C) DHTMLX
